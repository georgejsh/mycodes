Run the runscript.sh file.

