javac -cp .:la4j-0.5.5.jar Solution.java
java -cp .:la4j-0.5.5.jar Solution < Wiki-Vote.txt > ../OUTPUT/1.txt 
